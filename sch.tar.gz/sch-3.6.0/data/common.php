<?php

require_once('/var/lib/sch/sch-3.6.0/data/gan.php');
require_once('/var/lib/sch/sch-3.6.0/data/tj.php');

date_default_timezone_set('Asia/Karachi');

class Obj{
}

function GetToday($format)
{
	//return "2017-08-12";
	return Date($format);
}

?>
